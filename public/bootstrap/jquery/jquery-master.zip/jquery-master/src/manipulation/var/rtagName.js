define(function() {
	return ( /<([\w:-]+)/ );
});
