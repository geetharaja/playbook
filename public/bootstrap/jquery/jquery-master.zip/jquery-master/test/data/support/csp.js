jQuery(function() {
	parent.iframeCallback( getComputedSupport( jQuery.support ) );
});
